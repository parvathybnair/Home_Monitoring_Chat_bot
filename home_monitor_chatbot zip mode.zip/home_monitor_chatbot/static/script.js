// HomeGuardAI - Chat functionality and status updates

const chatForm = document.getElementById('chatForm');
const messageInput = document.getElementById('messageInput');
const chatMessages = document.getElementById('chatMessages');
const refreshBtn = document.getElementById('refreshBtn');
const clearHistoryBtn = document.getElementById('clearHistoryBtn');
const micBtn = document.getElementById('micBtn');
const themeToggleBtn = document.getElementById('themeToggleBtn');

// API endpoints
const API_BASE = '/api';

// Track if currently speaking
let isSpeaking = false;

// Preferred female voice (cached after first lookup)
let femaleVoice = null;

// Speech recognition
let recognition = null;
let isListening = false;

// ============ INITIALIZATION ============
document.addEventListener('DOMContentLoaded', () => {
    console.log('🚀 HomeGuardAI loaded');
    initTheme();
    loadHomeStatus();
    
    // Set up event listeners
    chatForm.addEventListener('submit', handleSendMessage);
    refreshBtn.addEventListener('click', loadHomeStatus);
    clearHistoryBtn.addEventListener('click', clearChatHistory);

    // Pre-load female voice
    loadFemaleVoice();
    // Voices may load async, so listen for changes
    if ('speechSynthesis' in window) {
        window.speechSynthesis.onvoiceschanged = loadFemaleVoice;
    }

    // Set up voice input
    setupVoiceInput();

    // Theme toggle
    if (themeToggleBtn) {
        themeToggleBtn.addEventListener('click', toggleTheme);
    }
});

// ============ THEME TOGGLE ============

/**
 * Initialize theme from localStorage or default to dark
 */
function initTheme() {
    const savedTheme = localStorage.getItem('homeguard-theme') || 'dark';
    document.body.setAttribute('data-theme', savedTheme);
    updateThemeIcon(savedTheme);
}

/**
 * Toggle between dark and light themes
 */
function toggleTheme() {
    const current = document.body.getAttribute('data-theme');
    const next = current === 'dark' ? 'light' : 'dark';
    document.body.setAttribute('data-theme', next);
    localStorage.setItem('homeguard-theme', next);
    updateThemeIcon(next);
}

/**
 * Update the toggle button icon
 */
function updateThemeIcon(theme) {
    if (!themeToggleBtn) return;
    const icon = themeToggleBtn.querySelector('i');
    if (theme === 'dark') {
        icon.className = 'fas fa-sun';
        themeToggleBtn.title = 'Switch to light mode';
    } else {
        icon.className = 'fas fa-moon';
        themeToggleBtn.title = 'Switch to dark mode';
    }
}

// ============ VOICE INPUT (Speech-to-Text) ============

/**
 * Set up the Web Speech API for voice commands
 */
function setupVoiceInput() {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (!SpeechRecognition) {
        console.warn('⚠️ Speech Recognition not supported in this browser');
        if (micBtn) {
            micBtn.title = 'Voice input not supported in this browser';
            micBtn.style.opacity = '0.4';
            micBtn.style.cursor = 'not-allowed';
        }
        return;
    }

    recognition = new SpeechRecognition();
    recognition.lang = 'en-US';
    recognition.interimResults = true;
    recognition.continuous = false;
    recognition.maxAlternatives = 1;

    // When speech is recognized
    recognition.onresult = (event) => {
        let finalTranscript = '';
        let interimTranscript = '';
        
        for (let i = event.resultIndex; i < event.results.length; i++) {
            const transcript = event.results[i][0].transcript;
            if (event.results[i].isFinal) {
                finalTranscript += transcript;
            } else {
                interimTranscript += transcript;
            }
        }
        
        // Show interim results in the input as the user speaks
        if (interimTranscript) {
            messageInput.value = interimTranscript;
            messageInput.placeholder = '🎤 Listening...';
        }
        
        // When we have a final result, put it in the input and auto-send
        if (finalTranscript) {
            messageInput.value = finalTranscript;
            stopListening();
            // Auto-send the voice command
            setTimeout(() => {
                chatForm.dispatchEvent(new Event('submit'));
            }, 300);
        }
    };

    recognition.onstart = () => {
        isListening = true;
        micBtn.classList.add('recording');
        messageInput.placeholder = '🎤 Listening... Speak now!';
        messageInput.value = '';
        console.log('🎤 Voice recognition started');
    };

    recognition.onend = () => {
        stopListening();
    };

    recognition.onerror = (event) => {
        console.error('🎤 Speech recognition error:', event.error);
        stopListening();
        if (event.error === 'no-speech') {
            messageInput.placeholder = 'No speech detected. Try again...';
        } else if (event.error === 'not-allowed') {
            messageInput.placeholder = 'Microphone access denied. Please allow mic access.';
        }
        setTimeout(() => {
            messageInput.placeholder = 'Ask about your home...';
        }, 3000);
    };

    // Mic button click handler
    micBtn.addEventListener('click', toggleListening);
    
    console.log('🎤 Voice input ready');
}

/**
 * Toggle listening on/off
 */
function toggleListening() {
    if (!recognition) return;
    
    if (isListening) {
        recognition.stop();
    } else {
        // Stop any current speech output before listening
        if ('speechSynthesis' in window) {
            window.speechSynthesis.cancel();
        }
        try {
            recognition.start();
        } catch (e) {
            console.error('Failed to start recognition:', e);
        }
    }
}

/**
 * Stop listening and reset UI
 */
function stopListening() {
    isListening = false;
    if (micBtn) {
        micBtn.classList.remove('recording');
    }
    messageInput.placeholder = 'Ask about your home...';
}

// ============ VOICE SETUP ============

/**
 * Find and cache a female voice for speech synthesis
 */
function loadFemaleVoice() {
    if (!('speechSynthesis' in window)) return;
    
    const voices = window.speechSynthesis.getVoices();
    if (voices.length === 0) return;
    
    // Priority list of female voice names (common across browsers)
    const femaleNames = [
        'Microsoft Zira',       // Windows
        'Google US English',    // Chrome (female by default)
        'Samantha',             // macOS
        'Karen',                // macOS Australian
        'Victoria',             // macOS
        'Fiona',                // macOS
        'Moira',                // macOS
        'Tessa',                // macOS
    ];
    
    // Try to find a matching female voice
    for (const name of femaleNames) {
        const match = voices.find(v => v.name.includes(name));
        if (match) {
            femaleVoice = match;
            console.log(`🔊 Female voice selected: ${match.name}`);
            return;
        }
    }
    
    // Fallback: find any English female voice
    const englishVoices = voices.filter(v => v.lang.startsWith('en'));
    if (englishVoices.length > 0) {
        // Pick the second voice if available (often female)
        femaleVoice = englishVoices.length > 1 ? englishVoices[1] : englishVoices[0];
        console.log(`🔊 Fallback voice selected: ${femaleVoice.name}`);
    }
}

// ============ CHAT FUNCTIONS ============

/**
 * Fetch with timeout - prevents infinite loading
 */
function fetchWithTimeout(url, options = {}, timeoutMs = 60000) {
    const controller = new AbortController();
    const { signal } = controller;

    const timeout = setTimeout(() => {
        controller.abort();
    }, timeoutMs);

    return fetch(url, { ...options, signal })
        .then(response => {
            clearTimeout(timeout);
            return response;
        })
        .catch(err => {
            clearTimeout(timeout);
            if (err.name === 'AbortError') {
                throw new Error('Request timed out. The AI took too long to respond. Please try again.');
            }
            throw err;
        });
}

/**
 * Show typing indicator in chat (replaces the old fullscreen spinner)
 */
function showTypingIndicator() {
    const typingDiv = document.createElement('div');
    typingDiv.className = 'message bot-message typing-indicator-wrapper';
    typingDiv.id = 'typingIndicator';

    typingDiv.innerHTML = `
        <div class="message-content typing-bubble">
            <div class="typing-indicator">
                <span class="dot"></span>
                <span class="dot"></span>
                <span class="dot"></span>
            </div>
        </div>
    `;

    chatMessages.appendChild(typingDiv);
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

/**
 * Remove typing indicator
 */
function removeTypingIndicator() {
    const indicator = document.getElementById('typingIndicator');
    if (indicator) {
        indicator.remove();
    }
}

// ============ ALEXA TOAST NOTIFICATIONS ============

/**
 * Show an Alexa command toast notification
 */
function showAlexaToast(commands) {
    const container = document.getElementById('alexaToastContainer');
    if (!container || !commands || commands.length === 0) return;

    const toast = document.createElement('div');
    toast.className = 'alexa-toast';

    const commandList = commands.map(cmd => `<div class="alexa-cmd-item">🔊 ${cmd}</div>`).join('');
    
    toast.innerHTML = `
        <div class="alexa-toast-header">
            <span class="alexa-logo">◆</span> Alexa Smart Home
        </div>
        <div class="alexa-toast-body">
            ${commandList}
        </div>
        <div class="alexa-toast-footer">✅ Commands executed successfully</div>
    `;

    container.appendChild(toast);

    // Trigger animation
    requestAnimationFrame(() => {
        toast.classList.add('show');
    });

    // Auto-remove after 5 seconds
    setTimeout(() => {
        toast.classList.remove('show');
        setTimeout(() => toast.remove(), 400);
    }, 5000);
}

/**
 * Send a chat message to the server
 */
async function handleSendMessage(e) {
    e.preventDefault();
    
    const message = messageInput.value.trim();
    if (!message) return;
    
    // Add user message to chat
    addMessageToChat(message, 'user');
    messageInput.value = '';
    
    // Disable input while waiting
    messageInput.disabled = true;
    chatForm.querySelector('.send-btn').disabled = true;
    
    // Show typing indicator (inline, not fullscreen)
    showTypingIndicator();
    
    try {
        const response = await fetchWithTimeout(`${API_BASE}/chat`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ message })
        }, 60000); // 60 second timeout
        
        if (!response.ok) {
            throw new Error(`Server error (HTTP ${response.status})`);
        }
        
        const data = await response.json();
        
        // Remove typing indicator before adding the response
        removeTypingIndicator();
        
        if (data.error) {
            addMessageToChat(`❌ Error: ${data.error}`, 'bot');
        } else {
            // Show Alexa toast if commands were executed
            if (data.alexa_commands && data.alexa_commands.length > 0) {
                showAlexaToast(data.alexa_commands);
                // Refresh sidebar status after commands
                setTimeout(loadHomeStatus, 500);
            }
            addMessageToChat(data.response, 'bot');
        }
    } catch (error) {
        console.error('Error:', error);
        removeTypingIndicator();
        addMessageToChat(
            `❌ ${error.message || 'Error connecting to server. Please check if the server is running.'}`,
            'bot'
        );
    } finally {
        // Re-enable input
        messageInput.disabled = false;
        chatForm.querySelector('.send-btn').disabled = false;
        messageInput.focus();
    }
}

/**
 * Speak text using the browser SpeechSynthesis API (female voice)
 */
function speakText(text) {
    if (!('speechSynthesis' in window)) {
        console.warn('SpeechSynthesis not supported in this browser');
        return;
    }

    // Stop any current speech
    window.speechSynthesis.cancel();

    const utterance = new SpeechSynthesisUtterance(text);
    utterance.lang = 'en-US';
    utterance.rate = 1.0;
    utterance.pitch = 1.1; // Slightly higher pitch for feminine tone
    utterance.volume = 1.0;

    // Use the cached female voice if available
    if (femaleVoice) {
        utterance.voice = femaleVoice;
    }

    // Update speaking state
    utterance.onstart = () => {
        isSpeaking = true;
        document.querySelectorAll('.speaker-btn.speaking').forEach(btn => {
            btn.classList.remove('speaking');
        });
    };
    utterance.onend = () => {
        isSpeaking = false;
        document.querySelectorAll('.speaker-btn.speaking').forEach(btn => {
            btn.classList.remove('speaking');
        });
    };
    utterance.onerror = () => {
        isSpeaking = false;
        document.querySelectorAll('.speaker-btn.speaking').forEach(btn => {
            btn.classList.remove('speaking');
        });
    };

    window.speechSynthesis.speak(utterance);
}

/**
 * Add a message to the chat display
 */
function addMessageToChat(text, role) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}-message`;

    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';

    // Handle multi-line text and special formatting
    if (text.includes('\n')) {
        text.split('\n').forEach((line, index) => {
            if (line.trim()) {
                const p = document.createElement('p');
                p.textContent = line;
                contentDiv.appendChild(p);
            }
        });
    } else {
        const p = document.createElement('p');
        p.textContent = text;
        contentDiv.appendChild(p);
    }

    messageDiv.appendChild(contentDiv);

    // For bot messages, add speaker button and auto-speak
    if (role === 'bot') {
        const actionsDiv = document.createElement('div');
        actionsDiv.className = 'message-actions';

        const speakerBtn = document.createElement('button');
        speakerBtn.className = 'speaker-btn';
        speakerBtn.title = 'Listen to this message';
        speakerBtn.innerHTML = '<i class="fas fa-volume-up"></i>';
        speakerBtn.addEventListener('click', () => {
            // Toggle: if already speaking, stop
            if (isSpeaking) {
                window.speechSynthesis.cancel();
                isSpeaking = false;
                speakerBtn.classList.remove('speaking');
            } else {
                // Remove speaking class from all other buttons
                document.querySelectorAll('.speaker-btn.speaking').forEach(btn => {
                    btn.classList.remove('speaking');
                });
                speakerBtn.classList.add('speaking');
                speakText(text);
            }
        });

        actionsDiv.appendChild(speakerBtn);
        messageDiv.appendChild(actionsDiv);

        // Auto-speak the bot response
        speakText(text);
        speakerBtn.classList.add('speaking');
    }

    // Add timestamp
    const timeSpan = document.createElement('span');
    timeSpan.className = 'message-time';
    timeSpan.textContent = new Date().toLocaleTimeString([], {
        hour: '2-digit',
        minute: '2-digit'
    });
    messageDiv.appendChild(timeSpan);

    chatMessages.appendChild(messageDiv);

    // Scroll to bottom
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

/**
 * Clear chat history
 */
async function clearChatHistory() {
    if (!confirm('Are you sure you want to clear the chat history?')) {
        return;
    }
    
    // Stop any speech
    if ('speechSynthesis' in window) {
        window.speechSynthesis.cancel();
    }

    try {
        const response = await fetch(`${API_BASE}/clear-history`, {
            method: 'POST'
        });
        
        const data = await response.json();
        
        if (data.success) {
            // Clear messages from UI, keep welcome message
            chatMessages.innerHTML = `
                <div class="message bot-message">
                    <div class="message-content">
                        <p>👋 Welcome! I'm <strong>HomeGuardAI</strong>. Chat history cleared. Ready for new questions!</p>
                    </div>
                    <span class="message-time">Just now</span>
                </div>
            `;
            console.log('✅ Chat history cleared');
        }
    } catch (error) {
        console.error('Error clearing history:', error);
        alert('Failed to clear chat history');
    }
}

// ============ STATUS FUNCTIONS ============

/**
 * Load and display home status
 */
async function loadHomeStatus() {
    try {
        // Rotate the refresh button
        refreshBtn.style.animation = 'none';
        setTimeout(() => {
            refreshBtn.style.animation = 'spin 0.8s linear';
        }, 10);
        
        const response = await fetch(`${API_BASE}/status`);
        
        if (!response.ok) {
            throw new Error(`HTTP ${response.status}`);
        }
        
        const data = await response.json();
        
        if (data.success && data.state) {
            updateStatusDisplay(data.state);
        } else {
            console.error('Failed to load status:', data.error);
        }
    } catch (error) {
        console.error('Error loading status:', error);
        showStatusError(error.message);
    }
}

/**
 * Update the status display with current home state
 */
function updateStatusDisplay(homeState) {
    // Update doors
    updateStatusSection('doorsStatus', homeState.doors, '🚪');
    
    // Update windows
    updateStatusSection('windowsStatus', homeState.windows, '🪟');
    
    // Update climate
    const climateItems = [
        { label: '🌡️ Temperature', value: `${homeState.temperature}°C` },
        { label: '💧 Humidity', value: `${homeState.humidity}%` }
    ];
    updateClimateDisplay('climateStatus', climateItems);
    
    // Update lights
    updateStatusSection('lightsStatus', homeState.lights, '💡');
    
    // Update fans
    if (homeState.fans) {
        updateStatusSection('fansStatus', homeState.fans, '🌀');
    }
    
    // Update other
    const otherItems = [
        { label: '📡 Motion Detected', value: homeState.motion ? 'Yes' : 'No' }
    ];
    updateOtherDisplay('otherStatus', otherItems);
}

/**
 * Update a status section with key-value pairs
 */
function updateStatusSection(elementId, items, emoji) {
    const element = document.getElementById(elementId);
    if (!element) return;
    element.innerHTML = '';
    
    for (const [key, value] of Object.entries(items)) {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'status-item';
        
        const label = document.createElement('span');
        label.className = 'status-label';
        label.textContent = key.charAt(0).toUpperCase() + key.slice(1).replace('_', ' ');
        
        const valueSpan = document.createElement('span');
        valueSpan.className = `status-value ${value.toLowerCase()}`;
        valueSpan.textContent = value.charAt(0).toUpperCase() + value.slice(1);
        
        itemDiv.appendChild(label);
        itemDiv.appendChild(valueSpan);
        element.appendChild(itemDiv);
    }
}

/**
 * Update climate display
 */
function updateClimateDisplay(elementId, items) {
    const element = document.getElementById(elementId);
    element.innerHTML = '';
    
    items.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'status-item';
        
        const label = document.createElement('span');
        label.className = 'status-label';
        label.textContent = item.label;
        
        const valueSpan = document.createElement('span');
        valueSpan.className = 'status-value';
        valueSpan.textContent = item.value;
        valueSpan.style.background = '#ffeaa7';
        valueSpan.style.color = '#d63031';
        
        itemDiv.appendChild(label);
        itemDiv.appendChild(valueSpan);
        element.appendChild(itemDiv);
    });
}

/**
 * Update other status display
 */
function updateOtherDisplay(elementId, items) {
    const element = document.getElementById(elementId);
    element.innerHTML = '';
    
    items.forEach(item => {
        const itemDiv = document.createElement('div');
        itemDiv.className = 'status-item';
        
        const label = document.createElement('span');
        label.className = 'status-label';
        label.textContent = item.label;
        
        const valueSpan = document.createElement('span');
        valueSpan.className = `status-value ${item.value.toLowerCase()}`;
        valueSpan.textContent = item.value;
        
        itemDiv.appendChild(label);
        itemDiv.appendChild(valueSpan);
        element.appendChild(itemDiv);
    });
}

/**
 * Show status error
 */
function showStatusError(message) {
    const sections = ['doorsStatus', 'doorLocksStatus', 'windowsStatus', 'climateStatus', 'lightsStatus', 'fansStatus', 'otherStatus'];
    sections.forEach(id => {
        const element = document.getElementById(id);
        if (element) {
            element.innerHTML = `<p class="loading" style="color: #e74c3c;">Error: ${message}</p>`;
        }
    });
}

// ============ UI HELPERS ============

/**
 * Show/hide loading spinner (kept for backward compat but not used for chat)
 */
function showLoading(show) {
    const spinner = document.getElementById('loadingSpinner');
    if (!spinner) return;
    if (show) {
        spinner.classList.remove('hidden');
    } else {
        spinner.classList.add('hidden');
    }
}

// ============ AUTO-REFRESH ============

/**
 * Auto-refresh status every 30 seconds
 */
setInterval(loadHomeStatus, 30000);

// ============ SAMURAI ANIMATION ============

/**
 * Samurai-themed background: katana slashes + kanji watermark
 */
function initParticles() {
    const canvas = document.getElementById('particleCanvas');
    if (!canvas) return;
    
    const ctx = canvas.getContext('2d');
    const wrapper = canvas.parentElement;
    let slashes = [];
    let frame = 0;
    
    function resize() {
        canvas.width = wrapper.offsetWidth;
        canvas.height = wrapper.offsetHeight;
    }
    
    // --- KATANA SLASH EFFECT ---
    function createSlash() {
        const startX = Math.random() * canvas.width * 0.6 + canvas.width * 0.2;
        const startY = Math.random() * canvas.height * 0.6 + canvas.height * 0.2;
        const angle = (Math.random() - 0.5) * Math.PI * 0.6;
        const length = 80 + Math.random() * 120;
        
        return {
            x: startX,
            y: startY,
            angle: angle,
            length: length,
            progress: 0,
            speed: 0.06 + Math.random() * 0.03,
            opacity: 1,
            fadeSpeed: 0.015,
            width: 2 + Math.random() * 2,
            fading: false,
        };
    }
    
    function drawSlash(s) {
        if (s.opacity <= 0) return;
        
        const endX = s.x + Math.cos(s.angle) * s.length * s.progress;
        const endY = s.y + Math.sin(s.angle) * s.length * s.progress;
        
        // Glow effect
        ctx.save();
        ctx.shadowColor = `rgba(200, 200, 255, ${s.opacity * 0.6})`;
        ctx.shadowBlur = 15;
        
        // Main slash line
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(endX, endY);
        
        const gradient = ctx.createLinearGradient(s.x, s.y, endX, endY);
        gradient.addColorStop(0, `rgba(200, 210, 255, ${s.opacity * 0.1})`);
        gradient.addColorStop(0.5, `rgba(180, 200, 255, ${s.opacity * 0.5})`);
        gradient.addColorStop(1, `rgba(220, 230, 255, ${s.opacity * 0.2})`);
        
        ctx.strokeStyle = gradient;
        ctx.lineWidth = s.width;
        ctx.lineCap = 'round';
        ctx.stroke();
        
        // Thin bright core
        ctx.beginPath();
        ctx.moveTo(s.x, s.y);
        ctx.lineTo(endX, endY);
        ctx.strokeStyle = `rgba(255, 255, 255, ${s.opacity * 0.4})`;
        ctx.lineWidth = s.width * 0.3;
        ctx.stroke();
        
        ctx.restore();
    }
    
    function updateSlash(s) {
        if (!s.fading) {
            s.progress += s.speed;
            if (s.progress >= 1) {
                s.progress = 1;
                s.fading = true;
            }
        } else {
            s.opacity -= s.fadeSpeed;
        }
    }
    
    // --- SAMURAI KANJI WATERMARK ---
    function drawWatermark() {
        ctx.save();
        ctx.font = '140px serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillStyle = 'rgba(200, 30, 30, 0.08)';
        ctx.fillText('侍', canvas.width / 2, canvas.height / 2);
        ctx.restore();
    }
    
    // --- INIT & ANIMATE ---
    function init() {
        resize();
        slashes = [];
    }
    
    function animate() {
        frame++;
        ctx.clearRect(0, 0, canvas.width, canvas.height);
        
        // Background - use theme-aware colors via CSS variables
        const style = getComputedStyle(document.body);
        const topColor = style.getPropertyValue('--canvas-top').trim() || '#faf8fa';
        const bottomColor = style.getPropertyValue('--canvas-bottom').trim() || '#ffffff';
        const bg = ctx.createLinearGradient(0, 0, 0, canvas.height);
        bg.addColorStop(0, topColor);
        bg.addColorStop(1, bottomColor);
        ctx.fillStyle = bg;
        ctx.fillRect(0, 0, canvas.width, canvas.height);
        
        // Watermark
        drawWatermark();
        
        // Random slash every ~200 frames
        if (frame % 200 === 0 || (frame % 120 === 0 && Math.random() > 0.5)) {
            slashes.push(createSlash());
        }
        
        // Update and draw slashes
        slashes = slashes.filter(s => s.opacity > 0);
        slashes.forEach(s => {
            updateSlash(s);
            drawSlash(s);
        });
        
        requestAnimationFrame(animate);
    }
    
    window.addEventListener('resize', resize);
    init();
    animate();
}

// Start samurai animation after DOM is ready
document.addEventListener('DOMContentLoaded', initParticles);

console.log('✅ HomeGuardAI initialized');
